import React, { useState, useLayoutEffect } from "react";
import "./styles.css";

import Tree from "./Tree";
import { sample1 as structure } from './tree-data'

export default function App() {
  let [data, setData] = useState(structure);

  const handleClick = (node) => {
    console.log(node)
  }

  // const handleUpdate = (state) => {
  //   localStorage.setItem(
  //     "tree",
  //     JSON.stringify(state, function (key, value) {
  //       if (key === "parentNode" || key === "id") {
  //         return null;
  //       }
  //       return value;
  //     })
  //   );
  // };

  // useLayoutEffect(() => {
  //   try {
  //     let savedStructure = JSON.parse(localStorage.getItem("tree"));
  //     if (savedStructure) {
  //       setData(savedStructure);
  //     }
  //   } catch (err) {
  //     console.log(err);
  //   }
  // }, []);

  return (
    <div className="App">
      <h2>Imparative API</h2>
      {/* <Tree data={data} onUpdate={handleUpdate} onNodeClick={handleClick} /> */}
      <Tree data={data} onNodeClick={handleClick} />
    </div>
  );
}
