import React, { useState } from "react";
import { AiOutlineFile } from "react-icons/ai";
import { StyledFile } from "Tree/File/styles";
import { useTreeContext } from "Tree/state/TreeContext";
import { StyledName } from "Tree/styles.js";


const File = ({ name, node }) => {
  const { onNodeClick } = useTreeContext();
  const [clicked, setClicked] = useState(false)

  // let splitted = name?.split(".");
  // const ext = splitted[splitted.length - 1]

  const handleNodeClick = React.useCallback(
    (e) => {
      e.stopPropagation()
      onNodeClick({ node, isActive: true })
      setClicked(!clicked)
    },
    [node]
  );

  return (
    <StyledFile active={clicked} onClick={handleNodeClick} className="tree__file">
      <StyledName>
        <AiOutlineFile />
        &nbsp;&nbsp;{name}
      </StyledName>
    </StyledFile>
  );
};

export { File };
