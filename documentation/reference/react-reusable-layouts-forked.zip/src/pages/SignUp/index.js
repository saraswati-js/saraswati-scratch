import React from "react";

export default function SignUp() {
  return <h1>Sign Up</h1>;
}
