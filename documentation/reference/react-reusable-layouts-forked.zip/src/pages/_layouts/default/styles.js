import styled from "styled-components";

export const Wrapper = styled.div`
  background: linear-gradient(to bottom, #ffc5c5, #ff4949);
  height: 100%;
`;
