import React from "react";

export default function SignIn() {
  return <h1>Sign In</h1>;
}
